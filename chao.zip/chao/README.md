# LIVE dessert web app

*Automatically synced with your [v0.app](https://v0.app) deployments*

[![Deployed on Vercel](https://img.shields.io/badge/Deployed%20on-Vercel-black?style=for-the-badge&logo=vercel)](https://vercel.com/espinosalopezjuanjose2-gmailcoms-projects/v0-live-dessert-web-app)
[![Built with v0](https://img.shields.io/badge/Built%20with-v0.app-black?style=for-the-badge)](https://v0.app/chat/projects/tlHJEomS5KN)

## Overview

This repository will stay in sync with your deployed chats on [v0.app](https://v0.app).
Any changes you make to your deployed app will be automatically pushed to this repository from [v0.app](https://v0.app).

## Deployment

Your project is live at:

**[https://vercel.com/espinosalopezjuanjose2-gmailcoms-projects/v0-live-dessert-web-app](https://vercel.com/espinosalopezjuanjose2-gmailcoms-projects/v0-live-dessert-web-app)**

## Build your app

Continue building your app on:

**[https://v0.app/chat/projects/tlHJEomS5KN](https://v0.app/chat/projects/tlHJEomS5KN)**

## How It Works

1. Create and modify your project using [v0.app](https://v0.app)
2. Deploy your chats from the v0 interface
3. Changes are automatically pushed to this repository
4. Vercel deploys the latest version from this repository